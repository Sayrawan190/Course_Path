.data
    menu:      .asciiz "Menu:\n1. Option 1\n2. Option 2\n3. Option 3\n4. Exit\n"
    prompt:    .asciiz "Enter your choice: "
    invalid:   .asciiz "Invalid choice. Please try again.\n"

.text
.globl main
main:

    # Display the menu
    li      $v0, 4
    la      $a0, menu
    syscall

    # Get the user's choice
    li      $v0, 4
    la      $a0, prompt
    syscall

    li      $v0, 5
    syscall
    move    $t0, $v0

    # Call the corresponding procedure
    beq     $t0, 1, option1
    beq     $t0, 2, option2
    beq     $t0, 3, option3
    beq     $t0, 4, exit
    j       invalid_choice