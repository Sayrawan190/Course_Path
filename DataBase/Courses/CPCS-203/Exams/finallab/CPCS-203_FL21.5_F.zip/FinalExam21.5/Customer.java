/*
Final Lab Exam
Student Name:-----------------
Student ID:-------------------
Section:----------------------
Lab Instructor:---------------
*/

public class Customer {

    private String customerID, customerName;
    private int points;
   
    public Customer() {
    }

    public Customer(String customerID, String customerName,int points) {
        this.customerID = customerID;
        this.customerName = customerName;
        this.points = points;
    }

    public String getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    @Override
    public String toString() {
        return 
                "customerID: " + customerID 
                +"\ncustomerName: " + customerName 
                + "\npoints: " + points;
    }

    public double getPointsDiscount() {
        return (points >= 1000) ? 0.10 : 0;
    }

 }
