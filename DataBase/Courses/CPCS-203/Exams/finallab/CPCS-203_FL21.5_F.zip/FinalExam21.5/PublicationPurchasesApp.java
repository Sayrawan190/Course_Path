/*
Final Lab Exam
Student Name:-----------------
Student ID:-------------------
Section:----------------------
Lab Instructor:---------------
*/

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import static java.lang.Double.parseDouble;
import static java.lang.Integer.parseInt;
import java.util.ArrayList;
import java.util.Scanner;


public class PublicationPurchasesApp {

/*----------------------------------------------------------------------
    Q1: define here 3 ArrayList: 
      1- ArrayList to save all Publication objects and name it:  P
      2- ArrayList to save all Customer objects and name it:  C 
      3- ArrayList to save all Purchases objects and name it:  S
------------------------------------------------------------------------*/
	//Answer Q1:
       
	
	
	
//-----------------------------------------------------------------------
    public static void main(String[] args) throws FileNotFoundException {
        File f1=new File("input.txt");
        Scanner input=new Scanner(f1);
        File f2=new File("output.txt");
        PrintWriter output= new PrintWriter(f2);
        
        if(!f1.exists())
        {
            System.out.print("Input file does not exist");
            System.exit(0);
        }
                
        while(input.hasNext())
        {
        	//Command array used to store the command parts
            String [] Command=input.nextLine().split(" ");
            
            if(Command[0].equalsIgnoreCase("AddBook"))
            {
/*----------------------------------------------------------------------
    Q2: Implement AddBook Command: 
      1- First note that all the arguments for AddBook already been read in 
         Command 
      2- Create Book object 
      3- Add the Book object to the Publication ArrayList 'P'.
      4- In the output file write the following message:
         "Book with the title (Book Title) was added successfully"
------------------------------------------------------------------------*/
      //Answer Q2:
                
                
                
//-------------------------------------------------------------------------
            }
            else if(Command[0].equalsIgnoreCase("AddMagazine"))
            {
/*----------------------------------------------------------------------
    Q3: Implement AddMagazine Command: 
      1- First note that all the arguments for AddMagazine already been read 
         in Command 
      2- Create Magazine object 
      3- Add the Magazine object to the Publication ArrayList 'P'.
      4- In the output file write the following message:
         "Magazine with the title (Magazine Title) was added successfully"
------------------------------------------------------------------------*/
     //Answer Q3:
                
            	

 //--------------------------------------------------------------------
            }
            else if(Command[0].equalsIgnoreCase("AddCustomer"))
            {
                C.add(new Customer(Command[1],Command[2],parseInt(Command[3])));
                output.println("Customer with ID ("+Command[1]+") was added successfully");
            }
            
            else if(Command[0].equalsIgnoreCase("PrintCustomers"))
            {
/*----------------------------------------------------------------------
	    Q4: Implement PrintCustomers Command: 
	      1- Iterate the ArrayList Customers 'C'
	      2- In the output file Print Customer Information    
------------------------------------------------------------------------*/
       //Answer Q4:
          
            	
            	
//-------------------------------------------------------------------------
            }

            else if(Command[0].equalsIgnoreCase("Sell"))
            {
            	
/*----------------------------------------------------------------------
    Q5: Implement Sell Command: 
    
      1- First note that all the arguments for Sell already been read in Command 
      
      2- Add your code in a try and catch block, where the catch block here will 
         catch a publication not found exception (you will throw this exception
          in -Q7- 'findPublication' method)
          
      3- Sell command has 2 arguments: the publication title and the customer ID.
         a)search for the publication by calling 'findPublication' method that will
           check for the availability of the publication (exist in the publication 
           ArrayList+ Number of available copies>0) and return its index in case 
           it was found, otherwise an appropriate message should be shown in the 
           output file
           
         b)search for the customer by calling 'findCustomer' method that will
           check if customer exist in the Customer ArrayList and return its 
           index in case it was found, otherwise it will return -1 and you should 
           show an appropriate message in the output file
           
      4- In case both publication and customer were found:
         a)create Purchases object with their information to add it to Purchases 'P' ArrayList
         b)print receipt by calling the "printReceipt" method in the purchases class
         c)Don't forget to decrease the number of available copies for the sold
           publication by calling 'decrease' method in the publication class
------------------------------------------------------------------------*/
  //Answer Q5:
              
            	
            	
            	
            	
            	
 //--------------------------------------------------------------------
            }
            else if(Command[0].equalsIgnoreCase("Print_Books_with_Maximum_Number_of_Available_Copies"))
            {
/*----------------------------------------------------------------------
    Q6: Implement Print_Books_with_Maximum_Number_of_Available_Copies Command: 
      the constraint here is to printout in the output file the book information
      for the book with the maximum number of available copies.You need to implement 
      the interface Comparable in order to call and use the method compareTo( ) to 
      find the book with the maximum number of available copies .
------------------------------------------------------------------------*/
      //Answer Q6:
           
            	
            	
            	
 //--------------------------------------------------------------------------------------
            }
            else if(Command[0].equalsIgnoreCase("Quit"))
            {
                output.println("Thank you...!");
            }
        }
        output.flush();
        input.close();
        output.close();   
    }
    
    /*Q7: Edit this method to throw the Exception--------------- */
    public static int findPublication(String PublicationTitle) 
    {
        for(int i=0;i<P.size();i++)
        {
            if(P.get(i).getTitle().equalsIgnoreCase(PublicationTitle))
                if(P.get(i).isAvailable())
                    return i;
        }
        /*----------------------------------------------------------------------
        if reach this point, then that will mean the method search all the
            publication and did not find a match to return its index.
            So, you need to throw an Exception with a message:
            "The Publication titled (put the title of publication) was not found"
    ------------------------------------------------------------------------*/
        //Answer 7:


    //-------------------------------------------------------------------------------
    }
    
    
    public static int findCustomer(String CustomerID)
    {
        for(int i=0;i<C.size();i++)
        {
            if(C.get(i).getCustomerID().equalsIgnoreCase(CustomerID))
                return i;
        }
        return -1;
    }
    
}
