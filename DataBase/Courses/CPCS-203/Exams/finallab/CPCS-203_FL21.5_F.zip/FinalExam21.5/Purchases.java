/*
Final Lab Exam
Student Name:-----------------
Student ID:-------------------
Section:----------------------
Lab Instructor:---------------
*/

public class Purchases {

    private String receiptID;
    private Customer customer;
    private Publication publications;

    

    public Purchases() {  }

    public Purchases(Customer customer, Publication publications) {
        
        this.customer = customer;
        this.publications = publications;
        this.receiptID = generateReceiptNumber();
   
    }
    public String getReceiptID() {
        return receiptID;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Publication getPublications() {
        return publications;
    }

    public void setPublications(Publication publications) {
        this.publications = publications;
    }

    public String generateReceiptNumber() {
        return customer.getCustomerID() + customer.getPoints();
    }
     public StringBuilder PrintReceipt()
     {
         StringBuilder s=new StringBuilder();
         s.append("");
         s.append("\n---------------Receipt------------------\n");
         s.append("recipeID: "+receiptID+"\n");
         s.append("\n**Customer Information:**\n"+"---------------------\n");
         s.append(customer.toString()+"\n");
         if(publications instanceof Book)
             s.append(((Book)publications).toString()+"\n");
         else
             s.append(((Magazine)publications).toString()+"\n");
         s.append("Current Price:"+publications.current_price()+"\n");
         s.append("final Price:"+(publications.current_price()-(publications.current_price()*customer.getPointsDiscount())));
         
         return s;
     }
}
