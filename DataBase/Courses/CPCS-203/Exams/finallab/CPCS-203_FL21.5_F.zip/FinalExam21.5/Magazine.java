/*
Final Lab Exam
Student Name:-----------------
Student ID:-------------------
Section:----------------------
Lab Instructor:---------------
*/

public class Magazine {

    private String volume;
    private String type;

    public Magazine() {    }
    
    public Magazine(String title, int availableCopies, double price, String volume, String type) {
        super(title, price, availableCopies);
        this.volume = volume;
        this.type = type;
    }

    public String getVolume() {
        return volume;
    }

    public String getType() {
        return type;
    }

    public void setVolume(String volume) {
        this.volume = volume;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public double current_price() {
        return super.getPrice();
    }

    @Override
    public String toString() {
        return  "\n**Magazine Information:**\n"
        		+"-----------------------------"
                +super.toString()
                +"\nvolume: " + volume 
                +"\ntype: " + type
                +"\n-----------------------------";
    }

    
}
