/*
Final Lab Exam
Student Name:-----------------
Student ID:-------------------
Section:----------------------
Lab Instructor:---------------
*/

import java.util.Date;

public class Book {
    
    private String author;
    private double discount;
    private int publicationYear;

    public Book() {    }

    public Book(String title, double price, int availableCopies,int publicationYear, String author) {
        super(title, price, availableCopies);
        this.author = author;
        this.publicationYear = publicationYear;
        this.discount = specialDiscount(publicationYear);
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setPublicationYear(int publicationYear) {
        this.publicationYear = publicationYear;
    }

    public String getAuthor() {
        return author;
    }

    public double getDiscount() {
        return discount;
    }

    public int getPublicationYear() {
        return publicationYear;
    }
    
    @Override
    public double current_price() {
        return super.getPrice() - (super.getPrice() * (this.discount / 100));
    }

    @Override
    public int compareTo(Book b) {
        if (this.getAvailableCopies()>=b.getAvailableCopies()) 
            return 1;
         else 
            return -1;
        
    }
    
    @Override
    public String toString() {
        return "\n**Book Information**:\n"
        		+"-----------------------------"
                +super.toString()
                +"\nauthor: " + author 
                +"\ndiscount: " + discount 
                +"\npublicationYear: " + publicationYear
                +"\n-----------------------------";
    }
    public int specialDiscount(int year) {
        Date now = new Date();
        int diff = (now.getYear()+1900) - year;
        if (diff >= 5 ) {
            return 5;
        }
        return 0;
    }

}
