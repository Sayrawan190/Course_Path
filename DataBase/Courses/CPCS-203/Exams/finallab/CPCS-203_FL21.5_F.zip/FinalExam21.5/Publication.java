/*
Final Lab Exam
Student Name:-----------------
Student ID:-------------------
Section:----------------------
Lab Instructor:---------------
*/

public class Publication {

    private String title;
    private double price;
    private int availableCopies;
   

    public Publication() {
    }

    public Publication(String title,  double price, int availableCopies) {
        
        this.title = title;
        this.price = price;
        this.availableCopies = availableCopies;
    }

    public String getTitle() {
        return title;
    }

    public double getPrice() {
        return price;
    }


    public void setTitle(String title) {
        this.title = title;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getAvailableCopies() {
        return availableCopies;
    }

    public void setAvailableCopies(int availableCopies) {
        this.availableCopies = availableCopies;
    }

    public abstract double current_price();

    @Override
    public String toString() {
        return 
                 "\ntitle: "+ title 
                + "\nprice: " + price 
                + "\navailableCopies: " + availableCopies;
    }


    public boolean isAvailable() {
        return availableCopies > 0;
    }

    public boolean decrease() {
        if (isAvailable()) {
            availableCopies--;
            return true;
        }
        return false;
    }


}
