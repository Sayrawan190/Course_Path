package FLab23_5;

/*
Final Lab Exam for Student copy
Student Name: 
Student ID: 
Section: 
Lab Instructor: 
*/
public class Customer {
	private int CustomerID;
	private String FisrtName;
	private String LastName;
	private int BirthYear;
	private int PhoneNumber;
	private String EmailAddress;

    
    public Customer(int CustomerID,String FisrtName,String LastName, int BirthYear, int PhoneNumber, String EmailAddress){
        this.CustomerID = CustomerID;
        this.FisrtName = FisrtName;
        this.LastName = LastName;
        this.BirthYear = BirthYear;
        this.PhoneNumber = PhoneNumber;
        this.EmailAddress = EmailAddress;
    }
    public void setCustomerID(int CustomerID){
       this.CustomerID = CustomerID;
    }
     public int getCustomerID(){
       return CustomerID; 
    }
    public void setFisrtName(String FisrtName){
       this.FisrtName = FisrtName;
    }
     public String getFisrtName(){
       return FisrtName; 
    }
     public void setLastName(String LastName){
       this.LastName = LastName;
    }
     public String getLastName(){
       return LastName; 
    }
     public void setBirthYear(int BirthYear){
       this.BirthYear = BirthYear;
    }
     public int getBirthYear(){
       return BirthYear; 
    }
     public void setPhoneNumber(int PhoneNumber){
       this.PhoneNumber = PhoneNumber;
    }
     public int getPhoneNumber(){
       return PhoneNumber; 
    }
     public void setEmailAddress(String EmailAddress){
       this.EmailAddress = EmailAddress;
    }
     public String getEmailAddress(){
       return EmailAddress; 
    }
     
    public String toString(){
        return " Customer ID : "+this.CustomerID+" Name : "+this.FisrtName+" "+this.LastName+" Phone Number : "+this.PhoneNumber+
                " Email Address : "+this.EmailAddress;
    }
}
