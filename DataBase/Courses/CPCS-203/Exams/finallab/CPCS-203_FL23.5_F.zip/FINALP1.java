package FLab23_5;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Scanner;
/*
Final Lab Exam for Student copy
Student Name: 
Student ID: 
Section: 
Lab Instructor: 
*/
public class FINALP1 {
	
    /* Q1: Complete the classes  declarations following the UML diagram 
     *(i.e., specify Abstract classes and Inheritance Relationships).  
     */
	
    /* Q2: Override the toString method in the PrivateTour class to return all PrivateTour information 
    (e.g., TourID, Destination, Capacity, Status, and Luxury Transport ).
     */
	
    /*----------------------------------------------------------------------
    Q3:Create three ArrayLists in the main class (FINALP1) as mentioned in the Exam Form
    ------------------------------------------------------------------------*/
//Solution:
   
    
   //=======================================================================
    public static void main(String[] args) throws FileNotFoundException {

        File F1 = new File("INPUT.txt");
        File F2 = new File("OUTPUT.txt");
        if (!F1.exists()) {
            System.out.println("Input file " + F1.getName() + " does not exist");
            System.exit(0);
        }
        Scanner input = new Scanner(F1);
        PrintWriter output = new PrintWriter(F2);
        output.println("\nWelcome to Al Aulla Tour Booking System!\n");
        output.println("***********************************************");

        String command;

        do {
            command = input.next();

            if (command.equalsIgnoreCase("ADD_Customer")) {
                AddCustomer(input, output);// // Reading data from the file
            } else if (command.equalsIgnoreCase("ADD_Tour")) {
                AddTour(input, output);// // Reading data from the file
            } else if (command.equalsIgnoreCase("BOOKING")) {
                Booking(input, output);// // Reading data from the file
            }
        } while (!command.equalsIgnoreCase("Quit"));

        output.println("\nThank you for using the Al Aulla Tour Booking System , Good Bye!");
        output.flush(); // immediately save in the file
        output.close(); // closing file write object
        input.close();// closing file read object
    }
     
    
    //==============================================================================
    //Q4: Implement the AddCustomer method
    public static void AddCustomer(Scanner input, PrintWriter output) {
        //Solution:
        
        
     }//end Add Customer   
    //===========================================================================
    
    
   //Q5:Implement the AddTour method
    public static void AddTour(Scanner input, PrintWriter output) {
   //Solution:

   
 }// end AddTour               
 //================================================================================== 
    
    
    //Q6. Implement the Booking method 
    public static void Booking(Scanner input, PrintWriter output) {
           //Solution
           
    } //end booking  
  //==================================================================================  
     //This method search about Tour ID and returns its index,  if tour not found it returns -1
    public static int searchTourIndex(int Tour_ID){
        int index = -1;
        for (int i = 0; i < tour.size(); i++) {
            if (tour.get(i).getTourID()== Tour_ID) {
                index= i;
            }
        }
        return index;
    }
  //=====================================================================================  
    //This method search about customer ID and returns its index,  if customer not found it returns -1
    public static int searchCustomerIndex(int Customer_id){
        int index = -1;
        for (int i = 0; i < customer.size(); i++) {
            if (customer.get(i).getCustomerID()==Customer_id) {
                index= i;
            }
        }
        return index;
    }
  //=====================================================================================
}
