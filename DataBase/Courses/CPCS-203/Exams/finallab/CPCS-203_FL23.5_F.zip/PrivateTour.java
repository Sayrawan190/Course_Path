package FLab23_5;

/*
Final Lab Exam for Student copy
Student Name: 
Student ID:
Section: 
Lab Instructor: 
*/
public class PrivateTour extends Tour {
	
	private String LuxuryTransport;
    
    public PrivateTour(int TourID,String Destination,int Capacity,String Status,String LuxuryTransport)
    {
    super(TourID,Destination,Capacity,Status);	
    this.LuxuryTransport=LuxuryTransport;
    }
    
    public void SetLuxuryTransport(String LuxuryTransport){
        this.LuxuryTransport = LuxuryTransport;
     }
     
    public String getLuxuryTransport(){
        return LuxuryTransport; 
     }
    
    
    /*Q2: Override the toString method in the PrivateTour class to return all PrivateTour information 
    (e.g., TourID, Destination, Capacity, Status, and Luxury Transport ).
     */
        @Override
    public String toString(){
    	//Solution:
        
        
      //=================================================================================
    }
    

}
