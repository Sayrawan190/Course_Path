package FLab23_5;

/*
Final Lab Exam for Student copy
Student Name: 
Student ID: 
Section: 
Lab Instructor: 
*/
public ----- class Tour {
    
	private int TourID;
	private String Destination;
	private int Capacity;
	private String Status;
    
    public Tour(){
    }
    
    public Tour(int TourID,String Destination,int Capacity,String Status){
        this.TourID=TourID;
        this.Destination= Destination;
        this.Capacity = Capacity;
        this.Status = Status;
    }
  
    public void setTourID(int TourID){
       this.TourID = TourID;
    }
     public int getTourID(){
       return TourID; 
    }
     public void setDestination(String Destination){
       this.Destination = Destination;
    }
     public String getDestination(){
       return Destination; 
    }
     public void setCapacity(int Capacity){
       this.Capacity = Capacity;
    }
     public int getCapacity(){
       return Capacity; 
    }
     public void setStatus(String Status){
       this.Status = Status;
    }
     public String getStatus(){
       return Status; 
    }
    public String toString(){
        return "TourID : "+this.TourID+" Destination : " +this.Destination+
                " Capacity : "+this.Capacity+" Status: "+this.Status;
    }
}
