package FLab23_5;

/*
Final Lab Exam for Student copy
Student Name: 
Student ID: 
Section: 
Lab Instructor: 
*/
public class GroupTour extends Tour {
	
	private String BusTransport;
    
    public GroupTour(int TourID,String Destination,int Capacity,String Status,String BusTransport)
    {
    super(TourID,Destination,Capacity,Status);
    this.BusTransport=BusTransport;
    }
    
    public void setBusTransport(String BusTransport){
        this.BusTransport = BusTransport;
     }
     
    public String getBusTransport(){
        return BusTransport; 
     }
    
    public String toString(){
        return super.toString()+ " BusTransport : "+this.BusTransport;
    }

}
