package FLab23_5;

/*
Final Lab Exam for Student copy
Student Name: 
Student ID: 
Section: 
Lab Instructor: 
*/
public class Booking {
    private int BNo;
    private Tour tour;
    private Customer customer;
    
    
    public Booking(int BNo,Tour tour,Customer customer){
        this.BNo = BNo;
        this.tour = tour;
        this.customer = customer;
        
    }
    public void setTour(Tour tour ){
       this.tour = tour;
    }
     public Tour getTour(){
       return tour; 
    }
     
    
     public void setCustomer(Customer customer){
       this.customer = customer;
    }
     public Customer getCustomer(){
       return customer; 
    }
    public String toString(){
        return " Booking Number : "+this.BNo+" \nTour information : "+tour.toString();
    }
}
